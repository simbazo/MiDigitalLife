<?php

return[
    'unique_with' => 'Эта комбинация полей :fields уже существует.',
];
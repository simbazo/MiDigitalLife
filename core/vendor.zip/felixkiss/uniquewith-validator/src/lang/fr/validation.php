<?php

return[
    'unique_with' => 'La combinaison des champs :fields existe déjà.',
];
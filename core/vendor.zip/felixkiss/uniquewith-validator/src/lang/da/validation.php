<?php

return[
    'unique_with' => 'Kombinationen af :fields eksisterer allerede.',
];

<?php

return[
    'unique_with' => 'A combinação de :fields já existe.',
];

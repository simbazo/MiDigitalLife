<?php

return[
    'unique_with' => ':fields alan kombinasyonları daha önceden kaydedilmiş.',
];
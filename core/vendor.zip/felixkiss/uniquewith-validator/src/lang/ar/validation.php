<?php
return[
    'unique_with' => 'هذا ال:fields قد تم اختياره مسبقا ',
];

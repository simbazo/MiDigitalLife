<?php

return[
    'unique_with' => 'Diese Kombination der Felder :fields existiert bereits.',
];
